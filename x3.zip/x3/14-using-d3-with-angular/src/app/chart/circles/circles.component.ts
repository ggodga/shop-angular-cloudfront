import { Component, Input } from '@angular/core'

@Component({
  selector: '[appCircles]',
  template: ``,
  styleUrls: ['./circles.component.css']
})
export class CirclesComponent {
}

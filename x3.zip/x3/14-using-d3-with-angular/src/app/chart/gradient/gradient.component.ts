import { Component, Input, SimpleChanges, OnChanges } from '@angular/core'

@Component({
  selector: '[appGradient]',
  template: ``,
})
export class GradientComponent {
}

import { Component, Input } from '@angular/core'
import { useAccessor } from '../utils';

@Component({
  selector: '[appBars]',
  template: ``,
  styleUrls: ['./bars.component.css']
})
export class BarsComponent {
}
